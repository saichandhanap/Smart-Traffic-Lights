# Traffic-Monitoring-System
Traffic Monitoring System implemented using MATLAB and Raspberry Pi involving image processing techniques in MATLAB. It processes the traffic density and controls the traffic lights thereby depending on the need.
